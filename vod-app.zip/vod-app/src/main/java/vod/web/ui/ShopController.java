package vod.web.ui;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import vod.model.Shop;
import vod.service.ShopService;

import java.util.List;

@Controller
@RequiredArgsConstructor
@Slf4j
public class ShopController {

    private final ShopService shopService;

    @GetMapping("/shops")
    String getShops(Model model) {
        log.info("about to display shops list");
        List<Shop> shops = shopService.getAllShops();
        model.addAttribute("shops", shops);

        return "shopsView";
    }
}
